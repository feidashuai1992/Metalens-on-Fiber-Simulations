function [data_x2, data_y2, p] = gds_generation(testDesign, X, Y)

% Separate the binary mask with several enclosed images
[labeledImage,numRegions] = bwlabel(testDesign);
props_mask = regionprops(labeledImage,'Area');
for k = 1 : numRegions
    thisRegion = ismember(labeledImage,k);    
    thisRegion = double(thisRegion);
    boundaries = bwboundaries(thisRegion);
    numberOfBoundaries = size(boundaries,1);
for l = 1:numberOfBoundaries
    thisBoundary = boundaries{l};
    row = thisBoundary(:,1);
    col = thisBoundary(:,2);
    x = X(row,col);
    y = Y(row,col);
end
    my_field = strcat('v',num2str(k));
    data_x1.(my_field) = x(1,:);
    data_y1.(my_field) = (y(:,1))';
end

% Transfer the edge coordiantes of the images to corresponding polygons 
count = 0;
for i = 1:numRegions
    my_field = strcat('v',num2str(i));
    ho = data_x1.(my_field);
    ve = data_y1.(my_field);
    pgon = polyshape(ho,ve,'Simplify',true);
    ho = (pgon.Vertices(:,1))';
    ve = (pgon.Vertices(:,2))';
    props_ho = regionprops(~isnan(ho),ho,'PixelValues');
    props_ve = regionprops(~isnan(ve),ve,'PixelValues');
    n = size(props_ho,1);
    for j = 1:n
        p = i+j+count-1;
        my_field = strcat('v',num2str(p));
        data_x2.(my_field) = props_ho(j).PixelValues;
        data_y2.(my_field) = props_ve(j).PixelValues;
    end
    count = count+n-1;
end

end