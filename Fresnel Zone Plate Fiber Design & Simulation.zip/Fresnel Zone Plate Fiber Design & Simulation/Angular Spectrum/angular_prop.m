function [X, Y, U2] = angular_prop(U, z, lambda, FOV, res, padsize, scale)

%--- Input field -------------------------------------------------------
% Generate new coordinates for the image planes
U1 = padarray(U,[padsize,padsize]);
U1 = imresize(U1,scale);

% Scale the input coordinates
x = scale*FOV*((res+2*padsize)/res);
y = scale*FOV*((res+2*padsize)/res);
x = linspace(-x,x,(res+2*padsize)*scale);
y = linspace(-y,y,(res+2*padsize)*scale);
[X, Y] = meshgrid(x, y);

dx = x(2) - x(1);
dy = y(2) - y(1);

% field_original is your M×N complex field (amplitude & phase)
[M, N] = size(U1);

%--- Spatial frequencies -----------------------------------------------
fx = (-N/2 : N/2-1) / (N*dx);    
fy = (-M/2 : M/2-1) / (M*dy);    
[FX, FY] = meshgrid(fx, fy);

%--- Angular spectrum transfer function --------------------------------
k = 2*pi / lambda;
H = exp(1i*k*z*sqrt(1-(lambda*FX).^2-(lambda*FY).^2));

% remove evanescent components (optional but numerically stable)
H((lambda*FX).^2 + (lambda*FY).^2 > 1) = 0;

%--- Forward and inverse FFTs ------------------------------------------
% shift so that zero-freq is at (1,1) before FFT
FTU1 = fftshift(fft2(fftshift(U1)));
AS = FTU1.*H;
U2 = fftshift(ifft2(fftshift(AS)));

end