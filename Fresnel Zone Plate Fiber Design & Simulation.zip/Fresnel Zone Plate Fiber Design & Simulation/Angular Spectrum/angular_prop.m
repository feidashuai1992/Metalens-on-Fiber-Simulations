function U2 = angular_prop(U1, dx, dy, z, lambda)
% U2 = angular_prop(U1, dx, dz, lambda)
% 
% Inputs:
%   U1     3000×3000 complex field at origin
%   dx     sampling pitch (dx = dy) [um]
%   dy     sampling pitch (dx = dy) [um]
%   dz     propagation distance [um]
%   lambda wavelength [um]
%
% Output:
%   U2     complex field at z

%--- Input field --------------------------------------------------------
% field_original is your M×N complex field (amplitude & phase)
[M, N] = size(U1);

%--- Spatial frequencies -----------------------------------------------
fx = (-N/2 : N/2-1) / (N*dx);    
fy = (-M/2 : M/2-1) / (M*dy);    
[FX, FY] = meshgrid(fx, fy);

%--- Angular spectrum transfer function -------------------------------
k = 2*pi / lambda;
H = exp(1i*k*z*sqrt(1-(lambda*FX).^2-(lambda*FY).^2));

% remove evanescent components (optional but numerically stable)
H((lambda*FX).^2 + (lambda*FY).^2 > 1) = 0;

%--- Forward and inverse FFTs ------------------------------------------
% shift so that zero-freq is at (1,1) before FFT
FTU1 = fftshift(fft2(fftshift(U1)));
AS = FTU1.*H;
U2 = fftshift(ifft2(fftshift(AS)));

end