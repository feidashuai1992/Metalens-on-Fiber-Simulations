function [data_x, data_y, k] = gds_generation(testDesign, X, Y)

% Separate the binary mask with several enclosed images
[labeledImage,numRegions] = bwlabel(testDesign);
for k = 1 : numRegions
    thisRegion = ismember(labeledImage,k);    
    thisRegion = double(thisRegion);
    boundaries = bwboundaries(thisRegion);
    thisBoundary = boundaries{1};
    x = X(thisBoundary(:,1),thisBoundary(:,2));
    y = Y(thisBoundary(:,1),thisBoundary(:,2));
    my_field = strcat('v',num2str(k));
    pgon = polyshape(x(1,:),(y(:,1))','Simplify',true);
    ho = (pgon.Vertices(:,1))';
    ve = (pgon.Vertices(:,2))';
    props_ho = regionprops(~isnan(ho),ho,'PixelValues');
    props_ve = regionprops(~isnan(ve),ve,'PixelValues');
    data_x.(my_field) = props_ho.PixelValues;
    data_y.(my_field) = props_ve.PixelValues;
end

end