clear all;
close all;

% Initial estimation of the wavefront curvature at the end of the fiber beam expander
% Length of the endcap (um) for Gaussian beam expansion
L = 750;

% Propagation matrix of light in the endcap
A = 1; B = L; C = 0; D = 1;

% Refractive index of the endcap estimated
n = 1.457;

% Wavelength of our laser in freespace
lambda = 0.6578;

% Gaussian mode radius at its waist (core-endcap interface)
w0 = 2;

% q parameter of the Gaussian beam at its waist, with wavefront curvature assumed to be infinity
q0 = 1/(1i*lambda/(pi*n*w0^2));

% q parameter of the Gaussian beam at z = L (endcap-air interface) caulclated by the propagation matrix
q1 = (A*q0+B)/(C*q0+D);

% Wavefront curvature of the Gaussian beam at z = L 
r1 = 1/real(1/q1);

% Gaussian mode radius at z = L
w1 = sqrt(lambda*(1/imag(1/q1))/(pi*n));

% Generate the field parameters
FOV = 150; 
MFD = 2*w1;
res = 3000;
x = linspace(0,FOV,res);
x = x - mean(x);
y = x;

dx = x(2) - x(1);
dy = y(2) - y(1);

[X,Y] = meshgrid(x,y);
[THETA,R] = cart2pol(X,Y);

% Phase compensation for the wavefront curvature of Gaussian beam at the end of the expander
phi = 2*pi*n*(r1-sqrt(r1.^2-R.^2))/lambda;
phi = wrapToPi(phi);
illum = exp(-R.^2/(0.25*MFD^2)).*exp(1i*phi);

% Plot the field distribution before the zone plate
figure (1);
imagesc(x,y,abs(illum));
axis equal;
axis tight;
xlabel('x (um)');
ylabel('y (um)');
colormap jet;
colorbar;

% Design the zone plate with focal distance and number of rings
f = 250;
N = 24;

for m = 1:N
    syms rm;
    eqn = n*sqrt(L^2+rm^2)+sqrt(rm^2+f^2) == n*L+f+(m-1)*lambda/2;
    Sv = vpasolve(eqn,rm,[0 inf]);
    r(:,m) = double(Sv);
end

blankField = zeros(res);
mask = blankField;

% Generate the mask
for i = 1:N/2
    mask(R > r(:,2*i-1) & R < r(:,2*i)) = 1;
end
testDesign = mask;

% Plot the mask
figure (2);
imagesc(x,y,testDesign);
axis equal;
axis tight;
xlabel('x (um)');
ylabel('y (um)');

% Calculate the field after the mask
diffInput = (1-testDesign).*illum;

% Plot the field after the mask
figure (3);
imagesc(x,y,abs(diffInput));
axis equal;
axis tight;
xlabel('x (um)');
ylabel('y (um)');
colormap jet;
colorbar;

% Generate new coordinates for farfield calculation
padsize = 2000;
scale = 0.5;
x1 = x/4;
y1 = y/4;
[X1, Y1] = meshgrid(x1, y1);

% Set up the depth range for calculation
tempIm_diffractive = [];
zVar = linspace(100,400,200);

% Calculate the farfield at each planes specified
for z = zVar
[X2, Y2, field_propagated] = angular_prop(diffInput, z, lambda, FOV, res, padsize, scale);
resamp = interp2(X2,Y2,field_propagated,X1,Y1);

figure (4);
imagesc(x1,y1,abs(resamp).^2);
axis equal;
axis tight;
xlabel('x (um)');
ylabel('y (um)');
colormap jet;
colorbar;

temp = resamp(:,round(size(resamp,1)/2));
tempIm_diffractive = [tempIm_diffractive, temp];
end

tempIm_diffractive(isnan(tempIm_diffractive)) = 0;

% Plot the intensity in xz plane
figure (5);
subplot(2,1,1);
imagesc(zVar(1:end), x1, abs(tempIm_diffractive).^2);
axis equal;
axis tight;
xlabel('z (um)');
ylabel('y (um)');
colormap jet;
colorbar;

subplot(2,1,2);
imagesc(zVar(1:end), x1, log10(abs(tempIm_diffractive).^2));
axis equal;
axis tight;
xlabel('z (um)');
ylabel('y (um)');
colormap jet;
colorbar;
saveas(gcf,'Surface Intensity XZ.tif');

% Plot the intensity along z axis
figure (6);
subplot(2,1,1);
plot(zVar(1:end),abs(tempIm_diffractive(res/2,:)).^2);
xlabel('z (um)');
ylabel('Intensity Linear');

subplot(2,1,2);
plot(zVar(1:end),log10(abs(tempIm_diffractive(res/2,:)).^2));
xlabel('z (um)');
ylabel('Intensity Log');
saveas(gcf,'Line Intensity.tif');

% Cut the zone plate in two halves to form enclosed shapes
% Generate the left half
blankField = zeros(res);
mask = blankField;
mask(X <= X(1,res/2)) = 1;
testDesign_left = testDesign.*mask;
[data_x1, data_y1, p] = gds_generation(testDesign_left, X, Y);

% Generate the right half
blankField = zeros(res);
mask = blankField;
mask(X >= X(1,res/2)) = 1;
testDesign_right = testDesign.*mask;
[data_x2, data_y2, q] = gds_generation(testDesign_right, X, Y);

% Transfer the polygons into a GDSII file
% The directories should be changed according to the saved file location
cd 'C:\Users\ezzfh2\OneDrive - The University of Nottingham\Desktop\Work\Documents\GitHub Projects\Metalens on Fiber Simulations\Fresnel Zone Plate Fiber Design & Simulation\Raith_GDSII-master';
for m = 1:p
    my_field = strcat('v',num2str(m));
    ho = data_x1.(my_field);
    ve = data_y1.(my_field);
    E(m) = Raith_element('polygon',0,[ho;ve],1.3);
end

for n = 1:q
    my_field = strcat('v',num2str(n));
    ho = data_x2.(my_field);
    ve = data_y2.(my_field);
    E(p+n) = Raith_element('polygon',0,[ho;ve],1.3);
end

S = Raith_structure('Poly',E);
L = Raith_library('FresnelZonePlate',S);
writegds(L,'plain');
cd 'C:\Users\ezzfh2\OneDrive - The University of Nottingham\Desktop\Work\Documents\GitHub Projects\Metalens on Fiber Simulations\Fresnel Zone Plate Fiber Design & Simulation\Angular Spectrum';
movefile 'C:\Users\ezzfh2\OneDrive - The University of Nottingham\Desktop\Work\Documents\GitHub Projects\Metalens on Fiber Simulations\Fresnel Zone Plate Fiber Design & Simulation\Raith_GDSII-master\FresnelZonePlate.gds';